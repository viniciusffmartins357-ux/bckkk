// Rode com: node --test testes/rastreio.test.mjs
import test from "node:test";
import assert from "node:assert/strict";
import { linhaDoTempo, limparCodigo, novoCodigo, dia } from "../netlify/lib/rastreio.mjs";

// Pago em 10/11 às 10h de Brasília (13h UTC).
const pago = "2026-11-10T13:00:00.000Z";
const em = (d, h = 12) => new Date(Date.UTC(2026, 10, d, h + 3)); // dia d, h horas em Brasília

test("no dia do pagamento aparece só 'Pedido recebido'", () => {
  const t = linhaDoTempo({ paidAt: pago }, em(10, 23));
  assert.deepEqual(t.passos.map((p) => p.titulo), ["Pedido recebido"]);
  assert.equal(t.amanha, "Pedido em produção");
});

test("avança exatamente 1 etapa por dia", () => {
  assert.equal(linhaDoTempo({ paidAt: pago }, em(11, 0)).atual, "Pedido em produção");
  assert.equal(linhaDoTempo({ paidAt: pago }, em(12)).atual, "Pedido em personalização");
  assert.equal(linhaDoTempo({ paidAt: pago }, em(16)).atual, "Em trânsito");
  assert.equal(linhaDoTempo({ paidAt: pago }, em(25)).atual, "Em trânsito"); // não marca entregue sozinho
});

test("pagamento às 23h de Brasília conta no mesmo dia (não no dia seguinte em UTC)", () => {
  assert.equal(dia("2026-11-11T02:30:00.000Z"), "2026-11-10");
});

test("nunca há 2 atualizações no mesmo dia, nem com 'entregue' marcado", () => {
  const o = { paidAt: pago, deliveredAt: em(12, 9).toISOString() }; // marcado no dia da personalização
  const no12 = linhaDoTempo(o, em(12, 20));
  assert.equal(no12.atual, "Pedido em personalização");
  assert.equal(no12.amanha, "Pedido entregue");
  const no13 = linhaDoTempo(o, em(13));
  assert.equal(no13.atual, "Pedido entregue");
  for (const d of [12, 13, 20]) {
    const datas = linhaDoTempo(o, em(d)).passos.map((p) => p.data);
    assert.equal(new Set(datas).size, datas.length);
  }
});

test("código de rastreio", () => {
  const c = novoCodigo();
  assert.match(c, /^BCK[A-Z2-9]{8}$/);
  assert.equal(limparCodigo(" bck-" + c.slice(3, 7) + " " + c.slice(7)), c);
  assert.equal(limparCodigo(c.slice(3)), c);
  assert.equal(limparCodigo("BCK123"), null);
});
